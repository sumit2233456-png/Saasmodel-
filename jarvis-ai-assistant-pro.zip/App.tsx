
import React, { useState, useRef, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Message, Role, MemoryItem } from './types';
import { JARVIS_CONFIG, QUICK_COMMANDS } from './constants';
import JarvisVisualizer from './components/JarvisVisualizer';
import ChatBubble from './components/ChatBubble';
import VitalsDisplay from './components/VitalsDisplay';
import { getGeminiChatResponse, generateSpeech, decodeAudioData } from './services/geminiService';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: `Sat-sri-akal Sumit Sir! Welcome back. Neural link active hai. My vision and search cores are online. Aapka goal: ${JARVIS_CONFIG.GOAL}—ye track par hai. Sab theek?`,
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    const saved = localStorage.getItem('jarvis_memory');
    return saved ? JSON.parse(saved) : [];
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    localStorage.setItem('jarvis_memory', JSON.stringify(memories));
  }, [messages, isThinking, memories]);

  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
  };

  const playResponseAudio = async (text: string) => {
    if (activeSourceRef.current) {
      try { activeSourceRef.current.stop(); } catch(e) {}
    }

    initAudio();
    const ctx = audioContextRef.current!;
    if (ctx.state === 'suspended') await ctx.resume();

    setIsSpeaking(true);
    try {
      const audioBytes = await generateSpeech(text);
      if (audioBytes) {
        const audioBuffer = await decodeAudioData(audioBytes, ctx);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => {
          setIsSpeaking(false);
          activeSourceRef.current = null;
        };
        activeSourceRef.current = source;
        source.start();
      } else {
        setIsSpeaking(false);
      }
    } catch (err) {
      console.error("Audio protocol failure", err);
      setIsSpeaking(false);
    }
  };

  // Fix: Complete handleImageSelect implementation
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendMessage = async (text: string, image?: string) => {
    if (!text.trim() && !image) return;

    const userMessage: Message = {
      id: uuidv4(),
      role: 'user',
      text: text || "Analyze image protocol active.",
      timestamp: new Date(),
      imageUrl: image || undefined,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setSelectedImage(null);
    setIsThinking(true);

    try {
      const history = messages.slice(-6).map(m => ({
        role: (m.role === 'assistant' ? 'model' : 'user') as 'model' | 'user',
        parts: [{ text: m.text }]
      }));

      const result = await getGeminiChatResponse(text || "Explain this Sir.", history, image || undefined);

      const assistantMessage: Message = {
        id: uuidv4(),
        role: 'assistant',
        text: result.text,
        timestamp: new Date(),
        sources: result.sources,
      };

      setMessages(prev => [...prev, assistantMessage]);
      await playResponseAudio(result.text);
    } catch (err) {
      console.error("AI Communication Error:", err);
    } finally {
      setIsThinking(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputValue, selectedImage || undefined);
  };

  const handleQuickCommand = (cmd: string) => {
    handleSendMessage(cmd);
  };

  const deleteMemory = (id: string) => {
    setMemories(prev => prev.filter(m => m.id !== id));
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-cyan-500/30">
      {/* Sidebar */}
      <aside className={`${isSidebarOpen ? 'w-80' : 'w-0'} transition-all duration-500 border-r border-slate-800/50 bg-slate-900/40 backdrop-blur-xl flex flex-col z-40`}>
        <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-8 h-8 bg-cyan-500 rounded flex items-center justify-center shadow-[0_0_15px_#06b6d4]">
              <span className="font-black text-black text-xs">JARVIS</span>
            </div>
            <h1 className="text-lg font-black uppercase tracking-widest text-white">Interface</h1>
          </div>

          <VitalsDisplay />

          <div className="mt-10">
            <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">Voice Protocols</h2>
            <div className="space-y-2">
              {QUICK_COMMANDS.map((q, i) => (
                <button 
                  key={i}
                  onClick={() => handleQuickCommand(q.cmd)}
                  className="w-full text-left p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-cyan-500/50 hover:bg-cyan-900/20 transition-all text-xs text-slate-400 hover:text-cyan-300"
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10">
            <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">Memory Cache</h2>
            <div className="space-y-3">
              {memories.length === 0 ? (
                <p className="text-[10px] text-slate-600 italic px-2">Encryption stable. No logs found.</p>
              ) : (
                memories.map(m => (
                  <div key={m.id} className="group p-3 rounded-xl bg-slate-800/20 border border-slate-800 hover:border-slate-700 transition-all relative">
                    <span className="text-[8px] font-bold uppercase text-cyan-500/60 mb-1 block">{m.category}</span>
                    <p className="text-[11px] text-slate-400 line-clamp-2">{m.content}</p>
                    <button 
                      onClick={() => deleteMemory(m.id)}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-slate-600 hover:text-red-400"
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        <div className="p-6 border-t border-slate-800/50">
          <p className="text-[9px] text-slate-600 uppercase tracking-[0.2em] text-center">Version 3.0 // Stark Industries</p>
        </div>
      </aside>

      {/* Main Chat Content */}
      <main className="flex-1 flex flex-col relative bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900/20 via-slate-950 to-slate-950">
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="absolute top-6 left-6 z-50 p-2.5 rounded-full bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 transition-all shadow-2xl backdrop-blur-md"
        >
          <svg className={`w-4 h-4 text-cyan-500 transition-transform duration-500 ${!isSidebarOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
        </button>

        <div className="flex-1 flex flex-col items-center pt-12 px-6 overflow-hidden">
          <JarvisVisualizer isThinking={isThinking} isSpeaking={isSpeaking} />
          
          <div ref={scrollRef} className="w-full max-w-4xl flex-1 overflow-y-auto px-4 py-8 custom-scrollbar space-y-4">
            {messages.map(m => (
              <ChatBubble key={m.id} message={m} />
            ))}
            {isThinking && (
              <div className="flex gap-2 p-4 text-cyan-500/50 animate-pulse text-[10px] font-black tracking-widest uppercase items-center">
                <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                Initializing Neural Response...
              </div>
            )}
          </div>
        </div>

        {/* Input Control Center */}
        <div className="p-8 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent backdrop-blur-sm">
          <div className="max-w-3xl mx-auto">
            {selectedImage && (
              <div className="mb-4 relative inline-block animate-in fade-in slide-in-from-bottom-2">
                <img src={selectedImage} alt="Preview" className="h-24 w-24 object-cover rounded-2xl border-2 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)]" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-2xl hover:bg-red-600 transition-colors"
                >
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="relative flex items-center gap-3">
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 transition-all group active:scale-95"
              >
                <svg className="w-5 h-5 text-slate-500 group-hover:text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                <input type="file" ref={fileInputRef} onChange={handleImageSelect} accept="image/*" className="hidden" />
              </button>

              <div className="flex-1 relative">
                <input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Awaiting command, Sir..."
                  className="w-full bg-slate-900/50 border border-slate-800 focus:border-cyan-500/50 rounded-2xl px-6 py-4.5 outline-none transition-all placeholder:text-slate-700 text-sm font-medium backdrop-blur-md"
                />
              </div>

              <button 
                type="submit"
                disabled={!inputValue.trim() && !selectedImage}
                className="p-4.5 rounded-2xl bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-900 disabled:text-slate-700 transition-all shadow-[0_0_25px_rgba(6,182,212,0.2)] group active:scale-95"
              >
                <svg className="w-5 h-5 text-white group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

// Fix: Add default export to resolve index.tsx error
export default App;
