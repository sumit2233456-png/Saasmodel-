
import React from 'react';
import { Message } from '../types';
import { JARVIS_CONFIG } from '../constants';

interface ChatBubbleProps {
  message: Message;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full mb-8 ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
      <div className={`max-w-[90%] md:max-w-[75%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        <div className="flex items-center gap-2 mb-1 px-2">
          {!isUser && <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-pulse"></div>}
          <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-500">
            {isUser ? JARVIS_CONFIG.OWNER : 'JARVIS CORE'}
          </span>
        </div>

        <div className={`relative px-5 py-4 rounded-3xl shadow-2xl border transition-all ${
          isUser 
            ? 'bg-blue-600/5 border-blue-500/20 text-blue-50 rounded-tr-none' 
            : 'bg-slate-900/60 border-slate-700/50 text-slate-100 rounded-tl-none backdrop-blur-md'
        }`}>
          {/* Glass Effect Overlay */}
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/5 to-transparent pointer-events-none"></div>

          {message.imageUrl && (
            <div className="mb-4 rounded-xl overflow-hidden border border-white/10 shadow-lg">
              <img src={message.imageUrl} alt="User Upload" className="max-h-64 w-full object-contain bg-black/20" />
            </div>
          )}

          <p className="text-sm leading-relaxed whitespace-pre-wrap font-medium relative z-10">{message.text}</p>
          
          {message.sources && message.sources.length > 0 && (
            <div className="mt-4 pt-3 border-t border-slate-700/50 relative z-10">
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-2">Grounding Sources</p>
              <div className="flex flex-wrap gap-2">
                {message.sources.map((source, i) => (
                  <a 
                    key={i} 
                    href={source.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[10px] bg-slate-800/80 hover:bg-cyan-900/40 border border-slate-700 hover:border-cyan-500/50 px-2 py-1 rounded transition-all text-slate-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                    {source.title.length > 20 ? source.title.substring(0, 20) + '...' : source.title}
                  </a>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between mt-3 opacity-40">
            <span className="text-[9px] mono uppercase tracking-tighter">
              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
            {!isUser && (
              <div className="flex gap-1">
                <div className="w-1 h-1 bg-cyan-500 rounded-full"></div>
                <div className="w-1 h-1 bg-cyan-500 rounded-full opacity-50"></div>
                <div className="w-1 h-1 bg-cyan-500 rounded-full opacity-20"></div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatBubble;
