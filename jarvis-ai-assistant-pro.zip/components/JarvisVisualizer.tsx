
import React from 'react';

interface JarvisVisualizerProps {
  isThinking: boolean;
  isSpeaking: boolean;
}

const JarvisVisualizer: React.FC<JarvisVisualizerProps> = ({ isThinking, isSpeaking }) => {
  return (
    <div className="relative flex items-center justify-center w-32 h-32 mb-6">
      {/* Outer Glow */}
      <div className={`absolute inset-0 rounded-full bg-cyan-500/10 blur-2xl transition-all duration-500 ${isThinking || isSpeaking ? 'scale-125 opacity-40' : 'scale-100 opacity-20'}`}></div>
      
      {/* Dynamic Rings */}
      <div className={`absolute w-full h-full border-2 border-cyan-500/30 rounded-full transition-all duration-300 ${isThinking ? 'animate-[spin_3s_linear_infinite]' : ''}`}></div>
      <div className={`absolute w-[80%] h-[80%] border border-cyan-400/50 rounded-full transition-all duration-300 ${isThinking ? 'animate-[spin_2s_linear_infinite_reverse]' : ''}`}></div>
      
      {/* Core */}
      <div className={`relative w-12 h-12 bg-cyan-500 rounded-full shadow-[0_0_30px_#06b6d4] flex items-center justify-center transition-all duration-300 ${isSpeaking ? 'scale-110 shadow-[0_0_50px_#22d3ee]' : 'scale-100'}`}>
        <div className="w-8 h-8 bg-black/40 rounded-full flex items-center justify-center">
          <div className={`w-2 h-2 bg-cyan-100 rounded-full ${isThinking ? 'animate-ping' : ''}`}></div>
        </div>
      </div>

      {/* Pulsing Waves for speaking */}
      {isSpeaking && (
        <>
          <div className="absolute w-full h-full border border-cyan-400/50 rounded-full animate-ping opacity-20"></div>
          <div className="absolute w-16 h-16 border border-cyan-400 rounded-full animate-ping opacity-40"></div>
        </>
      )}
    </div>
  );
};

export default JarvisVisualizer;
