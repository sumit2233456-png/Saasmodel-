
import React, { useState, useEffect } from 'react';

const VitalsDisplay: React.FC = () => {
  const [stats, setStats] = useState({
    cpu: 12,
    mem: 45,
    ping: 24,
    sync: 98.4
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats({
        cpu: Math.floor(Math.random() * 20) + 5,
        mem: Math.floor(Math.random() * 5) + 42,
        ping: Math.floor(Math.random() * 10) + 15,
        sync: 98 + Math.random()
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-2 gap-2 mt-6">
      <div className="bg-slate-800/20 border border-slate-700/30 p-2 rounded">
        <p className="text-[8px] text-slate-500 uppercase font-bold">Neural Load</p>
        <div className="flex items-center justify-between">
          <span className="text-xs mono text-cyan-400">{stats.cpu}%</span>
          <div className="w-12 h-1 bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-500 transition-all duration-1000" style={{ width: `${stats.cpu}%` }}></div>
          </div>
        </div>
      </div>
      <div className="bg-slate-800/20 border border-slate-700/30 p-2 rounded">
        <p className="text-[8px] text-slate-500 uppercase font-bold">Synapse Sync</p>
        <div className="flex items-center justify-between">
          <span className="text-xs mono text-emerald-400">{stats.sync.toFixed(1)}%</span>
        </div>
      </div>
      <div className="bg-slate-800/20 border border-slate-700/30 p-2 rounded">
        <p className="text-[8px] text-slate-500 uppercase font-bold">Latency</p>
        <p className="text-xs mono text-amber-400">{stats.ping}ms</p>
      </div>
      <div className="bg-slate-800/20 border border-slate-700/30 p-2 rounded">
        <p className="text-[8px] text-slate-500 uppercase font-bold">Uptime</p>
        <p className="text-xs mono text-slate-300">∞ ACTIVE</p>
      </div>
    </div>
  );
};

export default VitalsDisplay;
