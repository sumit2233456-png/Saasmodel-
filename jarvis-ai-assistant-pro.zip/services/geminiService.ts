
// Fix: Import Modality from @google/genai for strict typing in TTS config
import { GoogleGenAI, GenerateContentResponse, Type, Modality } from "@google/genai";
import { JARVIS_CONFIG } from "../constants";

// Fix: Direct usage of process.env.API_KEY as per guidelines
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiChatResponse = async (
  prompt: string, 
  history: { role: 'user' | 'model'; parts: { text: string }[] }[],
  imageB64?: string
) => {
  const ai = getAI();
  const model = 'gemini-3-flash-preview';
  
  const contents: any[] = [
    ...history.map(h => ({ role: h.role, parts: h.parts })),
  ];

  const userParts: any[] = [{ text: prompt }];
  if (imageB64) {
    userParts.push({
      inlineData: {
        data: imageB64.split(',')[1],
        mimeType: 'image/jpeg'
      }
    });
  }

  contents.push({ role: 'user', parts: userParts });

  const response = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction: JARVIS_CONFIG.SYSTEM_PROMPT,
      temperature: 0.8,
      tools: [{ googleSearch: {} }]
    }
  });

  // Fix: Extract grounding sources from candidates
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
    title: chunk.web?.title || 'Source',
    uri: chunk.web?.uri || ''
  })).filter((s: any) => s.uri) || [];

  return {
    text: response.text || '',
    sources
  };
};

/**
 * Sanitizes text for TTS to avoid 500 Internal errors.
 * Removes markdown, long strings, and unsupported symbols.
 */
const sanitizeForTTS = (text: string): string => {
  if (!text) return "";
  return text
    .replace(/[*_#`~>]/g, '') // Remove markdown
    .replace(/\[.*?\]/g, '') // Remove source brackets
    .replace(/\(.*?\)/g, '') // Remove parentheses content
    .replace(/[^\w\s.,!?'"अ-हा-्।\n]/gi, ' ') // Keep basic punctuation and Hindi characters
    .replace(/\s+/g, ' ')
    .trim()
    .substring(0, 250); // Limit length for stability
};

export const generateSpeech = async (text: string): Promise<Uint8Array | null> => {
  const sanitized = sanitizeForTTS(text);
  if (!sanitized) return null;

  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: sanitized }] }],
      config: {
        // Fix: Must be an array with a single Modality.AUDIO element
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) return null;
    
    return decode(base64Audio);
  } catch (error) {
    console.error("TTS System Alert:", error);
    // Silent fail to allow chat continuity
    return null;
  }
};

// LIVE API UTILITIES - Manual implementation required by guidelines
export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
