
export type Role = 'user' | 'assistant';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  timestamp: Date;
  imageUrl?: string;
  sources?: GroundingSource[];
  isStreaming?: boolean;
}

export interface MemoryItem {
  id: string;
  content: string;
  category: 'Note' | 'Goal' | 'Idea';
  timestamp: Date;
}

export interface AudioState {
  isPlaying: boolean;
  isListening: boolean;
}
